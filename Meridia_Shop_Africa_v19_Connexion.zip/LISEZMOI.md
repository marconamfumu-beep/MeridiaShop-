# Meridia Shop — marketplace panafricaine

Meridia Shop est une nouvelle base de marketplace issue des fonctionnalités de la version Paw/ZandoShop fournie, avec une identité visuelle propre à Meridia Shop. Le projet Firebase de l’ancien ZIP a été retiré : aucune donnée ni clé Firebase de ZandoShop n’est utilisée ici.

## Contenu

- `index.html` : vitrine et espace vendeur.
- `admin.html` : console d’administration.
- `shop.js`, `core.js`, `chat.js` : catalogue, fiches produits, vendeurs, demandes d’achat et messagerie.
- `firebase.js` : connexion Firebase Authentication / Cloud Firestore.
- `firebase-config.js` : emplacement de la configuration du NOUVEAU projet Firebase.
- `firestore.rules` : règles Firestore adaptées au profil vendeur Meridia.
- `netlify/functions/notify.mjs` : fonction Netlify pour les notifications.
- `netlify.toml` : configuration Netlify.

## Avant la mise en ligne

1. Créez un nouveau projet dans Firebase Console, par exemple `meridia-shop-africa`.
2. Ajoutez une application Web Firebase et copiez sa configuration dans `firebase-config.js` en remplaçant chaque valeur `COLLEZ_...`. Ne copiez aucune clé privée de compte de service.
3. Dans Firebase Authentication, activez **E-mail/Mot de passe** et **Connexion anonyme**. Les comptes vendeurs utilisent un identifiant interne dérivé du téléphone et un PIN de six chiffres.
4. Créez la base Cloud Firestore en mode production et publiez le contenu de `firestore.rules` dans l’onglet Règles.
5. Créez le premier document d’administration `admins/{UID}` dans Firestore, avec l’UID du compte Firebase qui doit être administrateur. Le document peut contenir `{ "role": "owner" }`. Les règles n’autorisent pas sa création depuis le navigateur.
6. Configurez les variables Netlify nécessaires à `netlify/functions/notify.mjs` avant d’activer les notifications. Pour les notifications Web Push, ajoutez aussi la clé VAPID publique dans `firebase-config.js`.
7. Déployez le contenu du ZIP sur Netlify. L’espace d’administration est accessible via `/admin.html`.

## Important

- Ce ZIP est une base de projet prête à configurer, mais il n’est pas encore connecté à un Firebase : les identifiants sont volontairement des valeurs de remplacement. Les comptes, la messagerie cloud, les commandes et l’administration ne seront réellement partagés entre appareils qu’après configuration du nouveau Firebase et publication des règles.
- Les moyens de paiement affichés sont des moyens déclaratifs (référence de transaction) ; aucun fournisseur de paiement n’est intégré automatiquement. Il faut conclure un contrat et intégrer l’API du prestataire choisi pour encaisser en ligne.
- L’inscription vendeur enregistre le pays et la ville. La gestion de l’activation/désactivation des pays depuis l’administration reste une évolution à ajouter avant d’ouvrir tous les pays.
- Vérifiez les règles et les fonctions de notification sur le nouveau projet avant d’accepter de vrais utilisateurs.

## Test local

Ouvrez `index.html` dans un serveur web local. Sans configuration Firebase, le site fonctionne en mode local sur cet appareil uniquement ; ne l’utilisez pas comme production multi-utilisateur.

## Design et portefeuille UBA

- L’accueil mobile a été refait selon la maquette Meridia Shop vert profond / or : en-tête compact, une seule recherche, univers/catégories, cartes produits et navigation basse.
- L’écran Compte affiche le portefeuille et permet de mémoriser le nom du titulaire, les 4 derniers chiffres et l’expiration d’une carte UBA prépayée. Le numéro complet et le CVV ne sont jamais demandés ni enregistrés.
- Cette mémorisation est uniquement visuelle sur l’appareil : elle ne débite pas la carte. Pour accepter réellement les paiements UBA, il faut intégrer la passerelle officielle UBA ou un prestataire agréé et ses identifiants marchands.


## Moyens de paiement configurables par l’administration
Dans `/admin.html` > Réglages, l’administrateur peut maintenant renseigner séparément les numéros M-Pesa, Orange Money et Airtel Money, ainsi que les instructions ou liens sécurisés pour carte bancaire Visa/Mastercard et carte prépayée UBA. Ces coordonnées sont partagées avec l’espace vendeur. Le vendeur choisit son moyen de paiement et transmet sa référence pour validation. Cette évolution ne réalise pas de débit automatique : les paiements par carte nécessitent toujours une passerelle officielle UBA ou un prestataire agréé. Ne jamais enregistrer le numéro complet d’une carte ni son CVV.


## Moyens de paiement par pays (v13)
- `/admin.html` > **Moyens de paiement** : l'administrateur ajoute, modifie, masque ou supprime des moyens pays par pays (54 pays, ou « Tous les pays ») : **Mobile Money**, **carte bancaire Visa/Mastercard**, **carte prépayée UBA**, **autre carte prépayée**, **virement bancaire**. Les opérateurs de chaque pays sont proposés automatiquement (saisie libre possible).
- Les moyens sont enregistrés dans `config/settings.methods` (lisibles par les vendeurs). Chaque vendeur voit en priorité ceux de son pays dans « Payer mon abonnement », et son menu de paiement est limité à ces moyens.
- Espace vendeur > Paiements : opérateurs Mobile Money selon le pays choisi (+ « Autre opérateur »), cartes UBA prépayée / Visa / Mastercard (4 derniers chiffres seulement).
- Sécurité : le numéro complet d'une carte et le CVV sont refusés (détection Luhn). Les cartes passent par un lien https sécurisé ou des instructions.
- **Republier `firestore.rules`** (le champ `method` d'un paiement n'est plus limité à 4 valeurs ; `brand` ajouté aux cartes vendeur).

## Session et cache (v14)
- Connexion conservée : le vendeur et l'administrateur restent connectés après fermeture de l'application (session Firebase locale + indice de rôle `ms_hint`, lu correctement au démarrage).
- Cache local `ms_pub` : les boutiques et produits s'affichent dès l'ouverture, puis sont mis à jour par Firestore. Les PIN et données privées ne sont pas mis en cache.
- Déconnexion : efface la session et l'indice local.

## Configuration Firebase et notifications (v14)
- `firebase-config.js` contient maintenant la configuration du projet `meridiashop1` et la clé VAPID publique (notifications Web Push).
- Côté Netlify, la fonction de notification a besoin de la variable d'environnement `FIREBASE_SERVICE_ACCOUNT` : le JSON de la clé de compte de service (Firebase Console > Paramètres du projet > Comptes de service > Générer une nouvelle clé privée). Cette clé ne doit jamais être publiée dans le ZIP ni dans le code.

## Messages d'erreur visibles (v15)
- Les messages apparaissent maintenant en haut de l'écran (ils étaient cachés par la barre du navigateur sur iPhone).
- Les formulaires de moyens de paiement vendeur et de paiement d'abonnement affichent le motif exact (numéro invalide, champ manquant, refus Firebase) au lieu de ne rien faire.
- Rappel : republie `firestore.rules`, sinon un paiement d'abonnement avec un nouveau moyen (ex. MTN) est refusé par Firebase.

## Notifications push (v16)
- Après « Activer les notifications », l'application envoie une notification de test. Si elle échoue, le message indique la cause : serveur mal configuré (variable `FIREBASE_SERVICE_ACCOUNT` absente sur Netlify), aucun appareil enregistré, ou jeton refusé.
- Sur iPhone, les notifications ne fonctionnent qu'après installation de l'application sur l'écran d'accueil (iOS 16.4 ou plus récent).

## Connexion client (v17)
- Les messages « Connexion impossible » et « Messagerie indisponible » indiquent maintenant la cause exacte.
- Causes habituelles : **Connexion anonyme** non activée dans Firebase Authentication, ou **meridiashop.netlify.app** absent des domaines autorisés (Authentication > Paramètres > Domaines autorisés).

## Panier et Compte (v18)
- Les boutons Panier et Compte ouvrent maintenant leur page et restent ouverts, même quand l'application se met à jour en arrière-plan (cause : le redessin Firebase effaçait la page Compte).
- Le panier liste les produits sélectionnés, permet de les retirer et propose une commande par vendeur sur WhatsApp.
