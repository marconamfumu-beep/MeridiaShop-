/* Meridia Shop : icônes SVG, page compte client, moyens de paiement vendeur et mise en page de l'espace vendeur.
   Chargé avant shop.js. Les moyens de paiement vendeur sont enregistrés dans d.vpay (Firestore : vpay). */
(function(){
const P={
grid:'<rect x="4" y="4" width="6" height="6" rx="1.5"/><rect x="14" y="4" width="6" height="6" rx="1.5"/><rect x="4" y="14" width="6" height="6" rx="1.5"/><rect x="14" y="14" width="6" height="6" rx="1.5"/>',
shirt:'<path d="M8 4L3 7l2 4 3-1v10h8V10l3 1 2-4-5-3a4 4 0 01-8 0z"/>',
shoe:'<path d="M3 16v-3l4-2 3 2 4 1c3 0 7 1 7 4v1H3z"/><path d="M3 19h18"/>',
bag:'<rect x="5" y="8" width="14" height="12" rx="2"/><path d="M9 8V6a3 3 0 016 0v2"/>',
beauty:'<path d="M9 3h6v3l1 2v11a2 2 0 01-2 2h-4a2 2 0 01-2-2V8l1-2z"/><path d="M9 11h6"/>',
headphones:'<path d="M4 14v-2a8 8 0 0116 0v2"/><rect x="4" y="14" width="3.5" height="6" rx="1.5"/><rect x="16.5" y="14" width="3.5" height="6" rx="1.5"/>',
home:'<path d="M3 11l9-8 9 8v9h-6v-6H9v6H3z"/>',
search:'<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
filter:'<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/>',
cart:'<path d="M3 4h3l2 11h10l2-8H7"/><circle cx="9" cy="19" r="1.5"/><circle cx="17" cy="19" r="1.5"/>',
chat:'<path d="M4 5h16v11H9l-5 4z"/>',
user:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
back:'<path d="M15 5l-7 7 7 7"/>',
gear:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>',
plus:'<path d="M12 5v14M5 12h14"/>',
clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
shield:'<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
bolt:'<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
card:'<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M3 10h18"/>',
phone:'<rect x="7" y="3" width="10" height="18" rx="2"/><path d="M11 18h2"/>'
};
const MI={
  ico(n){return '<svg class="mi" viewBox="0 0 24 24" aria-hidden="true">'+(P[n]||'')+'</svg>'},
  logo:'<svg viewBox="0 0 128 128" aria-hidden="true"><defs><linearGradient id="mgold" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#e9bb5b"/><stop offset="1" stop-color="#b98228"/></linearGradient></defs><rect x="5" y="5" width="118" height="118" rx="34" fill="#06372f"/><path d="M35 43V34a29 29 0 0 1 58 0v9" fill="none" stroke="url(#mgold)" stroke-width="7" stroke-linecap="round"/><path d="M26 43h76v66H26z" fill="#0b5144" stroke="url(#mgold)" stroke-width="4"/><path d="M39 91V60l25 22 25-22v31" fill="none" stroke="url(#mgold)" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/><circle cx="64" cy="46" r="3" fill="#fff2c9"/></svg>',
  uba:'<svg viewBox="0 0 24 26" aria-hidden="true"><path d="M9 2h6l-2 8 8-8h3L13 14l2 10h-4l-2-8-4 8H2l6-12z"/></svg>',
  africa:'<svg class="africa-svg" viewBox="0 0 230 240" aria-hidden="true"><path d="M38 6L93 3L99 16L122 22L160 21L162 26L176 59L221 84L202 115L189 128L183 143L187 156L171 198L157 218L122 234L96 181L98 141L86 122L89 109L70 102L58 104L45 105L24 101L2 75L6 64L27 24L36 13Z"/></svg>'
};
window.MI=MI;
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function toast(t){const e=document.getElementById('t');if(!e)return;e.textContent=t;e.className='on';clearTimeout(toast.h);toast.h=setTimeout(()=>{e.className=''},3000)}
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,7);

/* ---------- Mobile money : tous les pays du catalogue PAYM (paymethods.js) ---------- */
const MM_PROV={},MM_COUNTRY={},MM_LEN={};
PAYM.COUNTRIES.forEach(function(n){const i=PAYM.info(n);MM_COUNTRY[i.cc]=n;MM_PROV[i.cc]=i.mm.slice()});
MM_LEN['243']=[9,9];MM_LEN['229']=[8,8];
function normNum(cc,raw){let d=String(raw==null?'':raw).replace(/\D/g,'');if(cc==='243'&&d.length===10&&d[0]==='0')d=d.slice(1);else if(d.length>8&&d[0]==='0'&&cc!=='229')d=d.slice(1);return d}
function validMM(cc,prov,raw,holder){
  if(!MM_COUNTRY[cc])return 'Choisissez un pays valide';
  if(!String(prov||'').trim())return 'Choisissez ou indiquez l’opérateur';
  const d=normNum(cc,raw),r=MM_LEN[cc]||[7,12];
  if(d.length<r[0]||d.length>r[1])return r[0]===r[1]?'Le numéro doit comporter '+r[0]+' chiffres après +'+cc:'Le numéro doit comporter '+r[0]+' à '+r[1]+' chiffres après +'+cc;
  if(cc==='243'&&!/^[89]/.test(d))return 'Le numéro RDC doit commencer par 8 ou 9';
  if(!String(holder||'').trim())return 'Indiquez le nom du titulaire';
  return '';
}
function maskNum(num){return '•••• '+String(num).slice(-3)}

/* ---------- Moyens de paiement vendeur (logique pure, testée) ---------- */
const VPAY={
  MAX:8,
  cardExpOk(exp,now){const m=/^(0[1-9]|1[0-2])\/(\d{2})$/.exec(String(exp||''));if(!m)return false;const mo=+m[1],yr=2000+(+m[2]);const n=now||new Date();return yr>n.getFullYear()||(yr===n.getFullYear()&&mo>=n.getMonth()+1)},
  addCard(list,vid,f,now){
    const brand=['Carte prépayée UBA','Carte bancaire Visa / Mastercard','Autre carte prépayée'].indexOf(f.brand)>=0?f.brand:'Carte prépayée UBA',holder=String(f.holder||'').trim(),last4=String(f.last4||'').trim(),exp=String(f.exp||'').trim();
    if(!holder)return{error:'Indiquez le nom figurant sur la carte'};
    if(!/^\d{4}$/.test(last4))return{error:'Entrez les 4 derniers chiffres de la carte'};
    if(!VPAY.cardExpOk(exp,now))return{error:'Date d’expiration invalide ou dépassée'};
    if(list.filter(x=>x.vid===vid).length>=VPAY.MAX)return{error:'Limite de moyens de paiement atteinte'};
    if(list.some(x=>x.vid===vid&&x.kind==='card'&&x.last4===last4&&x.exp===exp))return{error:'Cette carte est déjà enregistrée'};
    const item={id:uid(),vid,kind:'card',brand,holder:holder.slice(0,60),last4,exp,date:Date.now()};
    list.push(item);return{ok:true,item};
  },
  addMM(list,vid,f){
    const pv=String(f.prov||'').split('|'),cc=pv[0],prov=pv.slice(1).join('|').trim().slice(0,40);
    const err=validMM(cc,prov,f.num,f.holder);if(err)return{error:err};
    if(list.filter(x=>x.vid===vid).length>=VPAY.MAX)return{error:'Limite de moyens de paiement atteinte'};
    const num=normNum(cc,f.num);
    if(list.some(x=>x.vid===vid&&x.kind==='mm'&&x.cc===cc&&x.prov===prov&&x.num===num))return{error:'Ce mobile money est déjà enregistré'};
    const item={id:uid(),vid,kind:'mm',cc,prov,num,holder:String(f.holder).trim().slice(0,60),date:Date.now()};
    list.push(item);return{ok:true,item};
  },
  remove(list,vid,id){const i=list.findIndex(x=>x.id===id&&x.vid===vid);if(i>=0)list.splice(i,1);return i>=0}
};
window.VPAY=VPAY;
window.MM={MM_PROV,MM_COUNTRY,validMM,normNum,maskNum};

/* ---------- Espace vendeur : onglet Paiements ---------- */
function provOptions(cc){const l=MM_PROV[cc]||[];return l.map(p=>`<option value="${cc}|${esc(p)}">${esc(p)}</option>`).join('')+`<option value="${cc}|">Autre opérateur…</option>`}
function vendorPayPanel(list,vid,country){
  const mine=(list||[]).filter(x=>x.vid===vid);
  const cards=mine.filter(x=>x.kind==='card'),mms=mine.filter(x=>x.kind==='mm');
  const row=x=>x.kind==='card'
    ?`<div class="vp-item"><span class="vp-ico">${MI.ico('card')}</span><div><b>${esc(x.brand||'Carte prépayée UBA')}</b><small>${esc(x.holder)} · •••• ${esc(x.last4)} · exp. ${esc(x.exp)}</small></div><button class="sm bad" data-vp-del="${esc(x.id)}">Retirer</button></div>`
    :`<div class="vp-item"><span class="vp-ico">${MI.ico('phone')}</span><div><b>${esc(x.prov)}</b><small>${esc(x.holder)} · +${esc(x.cc)} ${esc(maskNum(x.num))}</small></div><button class="sm bad" data-vp-del="${esc(x.id)}">Retirer</button></div>`;
  const cc0=(PAYM.COUNTRIES.indexOf(country)>=0?PAYM.info(country).cc:'243');
  const cOpts=PAYM.COUNTRIES.map(n=>`<option value="${PAYM.info(n).cc}"${PAYM.info(n).cc===cc0?' selected':''}>${esc(n)} (+${PAYM.info(n).cc})</option>`).join('');
  return `<div class="vp-intro"><h2>Moyens de paiement</h2><p class="mut">Comptes qui reçoivent vos encaissements${country?' en '+esc(country):''}. Les paiements en ligne ne sont pas encore branchés : ces informations servent à vos règlements.</p></div>
<div class="box"><h3>Cartes bancaires et prépayées (${cards.length})</h3>${cards.map(row).join('')||'<p class="mut">Aucune carte enregistrée.</p>'}</div>
<div class="box"><h3>Mobile money (${mms.length})</h3>${mms.map(row).join('')||'<p class="mut">Aucun compte mobile money enregistré.</p>'}</div>
<form id="vp-card" class="box vp-form" novalidate><h3>Ajouter une carte (UBA prépayée, Visa, Mastercard…)</h3>
  <div class="vp-grid">
    <label>Type de carte<select name="brand"><option>Carte prépayée UBA</option><option>Carte bancaire Visa / Mastercard</option><option>Autre carte prépayée</option></select></label>
    <label>Nom figurant sur la carte<input name="holder" required maxlength="60" placeholder="Nom du titulaire"></label>
    <label>4 derniers chiffres<input name="last4" required inputmode="numeric" pattern="[0-9]{4}" maxlength="4" placeholder="4567"></label>
    <label>Expiration (MM/AA)<input name="exp" required inputmode="numeric" pattern="(0[1-9]|1[0-2])/[0-9]{2}" maxlength="5" placeholder="12/27"></label>
  </div>
  <p class="mut">Ne saisissez jamais le numéro complet ni le CVV.</p>
  <button class="pri">Enregistrer la carte</button>
</form>
<form id="vp-mm" class="box vp-form" novalidate><h3>Ajouter un mobile money</h3>
  <div class="vp-grid">
    <label>Pays<select id="vp-country">${cOpts}</select></label>
    <label>Opérateur<select name="prov" id="vp-prov">${provOptions(cc0)}</select></label>
    <label id="vp-other-w" hidden>Nom de l’opérateur<input id="vp-other" maxlength="40" placeholder="Nom de l’opérateur"></label>
    <label>Numéro<div class="mm-phone"><span id="vp-cc" class="mm-cc">+${cc0}</span><input name="num" inputmode="tel" required maxlength="14" placeholder="Numéro sans indicatif"></div></label>
    <label>Nom du titulaire<input name="holder" required maxlength="60" placeholder="Nom complet"></label>
  </div>
  <button class="pri">Enregistrer le mobile money</button>
</form>`;
}
window.vendorPayPanel=vendorPayPanel;

/* Mise en page de l'espace vendeur : barre latérale à gauche, contenu à droite. */
function vendorLayout(){
  const m=document.getElementById('m');if(!m||!m.querySelector('[data-vt]'))return;
  if(m.querySelector('.vshell'))return;
  const tabs=m.querySelector(':scope > .tabs');if(!tabs)return;
  const shell=document.createElement('div');shell.className='vshell';
  const side=document.createElement('aside');side.className='vside';
  const main=document.createElement('div');main.className='vmain';
  m.insertBefore(shell,tabs);
  side.appendChild(tabs);shell.appendChild(side);
  while(shell.nextSibling)main.appendChild(shell.nextSibling);
  shell.appendChild(main);
}
window.vendorLayout=vendorLayout;

/* ---------- Page compte client : aucun moyen de paiement côté client ---------- */
function walletPage(){
  return `<section class="wallet-page">
  <div class="wallet-top">
    <div class="wallet-bar"><button class="wallet-back" data-home aria-label="Retour à l’accueil">${MI.ico('back')}</button><b>Mon compte</b><span class="wallet-gear" aria-hidden="true"></span></div>
    <p class="wc-sub">Votre compte client Meridia Shop.</p>
  </div>
  <div class="wallet-body">
    <div class="wallet-soon"><span class="wallet-mark">${MI.logo}</span><div><b>Mes commandes</b><small>Bientôt disponible</small></div></div>
    <div class="box"><h3>Paiements</h3><p class="mut">Chaque boutique vous indique ses moyens de paiement au moment de la commande. Meridia Shop ne demande et ne conserve aucune donnée de carte.</p></div>
    <div class="wallet-secure-list">
      <div>${MI.ico('shield')}<p><b>Vos transactions sont protégées</b><span>Sécurité renforcée et cryptage des données</span></p></div>
      <div>${MI.ico('bolt')}<p><b>Paiement rapide</b><span>Payez en toute simplicité</span></p></div>
      <div>${MI.ico('globe')}<p><b>Accepté partout en Afrique</b><span>Achetez dans tous les pays disponibles</span></p></div>
    </div>
  </div></section>`;
}
window.walletPage=walletPage;

/* Clics et saisies communs */
document.addEventListener('click',function(e){
  const s=e.target.closest('[data-soon]');
  if(s){e.preventDefault();toast(s.dataset.soon);return}
  if(e.target.closest('[data-chat-open]')){
    e.preventDefault();e.stopPropagation();
    if(window.ZCHAT&&ZCHAT.list)ZCHAT.list();else toast('Messagerie indisponible pour le moment');
  }
},true);
document.addEventListener('change',function(e){
  const t=e.target;if(!t)return;
  if(t.id==='vp-country'){const p=document.getElementById('vp-prov'),o=document.getElementById('vp-cc');if(p)p.innerHTML=provOptions(t.value);if(o)o.textContent='+'+t.value;syncOther()}
  if(t.id==='vp-prov'){const cc=String(t.value).split('|')[0],out=document.getElementById('vp-cc');if(out)out.textContent='+'+cc;syncOther()}
});
function syncOther(){const p=document.getElementById('vp-prov'),w=document.getElementById('vp-other-w');if(!p||!w)return;w.hidden=String(p.value).split('|')[1]!==''}

})();
