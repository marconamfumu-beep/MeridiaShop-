import{db,auth,json,adminUids,once,send}from'./_lib.mjs';
export default async req=>{
  if(req.method!=='POST')return json({error:'POST'},405);
  let u,b;
  try{u=await auth.verifyIdToken((req.headers.get('authorization')||'').replace(/^Bearer /,''))}catch(e){return json({error:'auth'},401)}
  try{b=await req.json()}catch(e){return json({error:'json'},400)}
  const t=String(b.type||''),id=String(b.id||'').slice(0,80),ago=m=>Date.now()-m*6e4,get=async(c,i)=>(await db.collection(c).doc(i).get()).data();
  try{
    if(t==='request'){const r=await get('requests',id);if(!r||r.date<ago(10)||!(await once('rq_'+id)))return json({ok:0});await send([r.vid],'Nouvelle demande d’achat',(r.productTitles||[]).join(', ').slice(0,120),'index.html');return json({ok:1})}
    if(t==='message'){const ch=String(b.chat||'').slice(0,200),c=await get('chats',ch);if(!c||(u.uid!==c.vid&&u.uid!==c.cid))return json({error:'forbidden'},403);const m=(await db.collection('chats').doc(ch).collection('messages').doc(id).get()).data();if(!m||m.uid!==u.uid||m.date<ago(10)||!(await once('ms_'+ch+'_'+id)))return json({ok:0});const tx=String(m.text||'').slice(0,120);if(m.from==='c')await send([c.vid],'Message de '+(c.name||'Client'),tx,'index.html#chat-'+ch);else{const v=await get('vendors',c.vid);await send([c.cid],(v&&v.shop)||'Vendeur',tx,'index.html#chat-'+ch)}return json({ok:1})}
    if(t==='payment'){const p=await get('payments',id);if(!p||p.vid!==u.uid||p.status!=='en attente'||!(await once('py_'+id)))return json({ok:0});await send(await adminUids(),'Paiement à valider',p.amount+' '+p.cur+' · '+p.method,'admin.html');return json({ok:1})}
    if(t==='vendor'){const v=await get('vendors',u.uid);if(!v||v.joined<ago(10)||!(await once('vd_'+u.uid)))return json({ok:0});await send(await adminUids(),'Nouveau vendeur',v.shop+' · '+v.city,'admin.html');return json({ok:1})}
    if(t==='decision'){if(!(await adminUids()).includes(u.uid))return json({error:'forbidden'},403);const p=await get('payments',id);if(!p||!['validé','refusé'].includes(p.status)||!(await once('dc_'+id+'_'+p.status)))return json({ok:0});await send([p.vid],p.status==='validé'?'Paiement validé ✔':'Paiement refusé',p.status==='validé'?'Votre abonnement est prolongé.':'Vérifiez la référence et réessayez.','index.html');return json({ok:1})}
    if(t==='test'){const s=await db.collection('devices').doc(u.uid).get(),tk=(s.exists&&s.data().tokens)||[];if(!tk.length)return json({ok:0,reason:'no-device'});const sent=await send([u.uid],'Meridia Shop','Les notifications fonctionnent ✔','index.html');return json({ok:sent?1:0,devices:tk.length,sent})}
  }catch(e){console.error(e);return json({error:'server'},500)}
  return json({error:'type'},400);
};
