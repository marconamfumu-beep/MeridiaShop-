import admin from 'firebase-admin';
if(!admin.apps.length)admin.initializeApp({credential:admin.credential.cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT))});
export const db=admin.firestore(),auth=admin.auth();
export const json=(o,s=200)=>new Response(JSON.stringify(o),{status:s,headers:{'Content-Type':'application/json'}});
export const adminUids=async()=>(await db.collection('admins').listDocuments()).map(d=>d.id);
/* Anti-doublon : renvoie true une seule fois par clé. */
export const once=async k=>{try{await db.collection('notif_log').doc(k).create({t:Date.now()});return true}catch(e){return false}};
export async function send(uids,title,body,url){
  const tokens=[];(await Promise.all(uids.map(u=>db.collection('devices').doc(u).get()))).forEach(s=>{if(s.exists)tokens.push(...(s.data().tokens||[]))});
  if(!tokens.length)return 0;
  const r=await admin.messaging().sendEachForMulticast({tokens,data:{title,body,url},webpush:{headers:{Urgency:'high',TTL:'86400'}}});
  const bad=[];r.responses.forEach((x,i)=>{if(!x.success&&/not-registered|invalid-registration/.test((x.error&&x.error.code)||''))bad.push(tokens[i])});
  if(bad.length)await Promise.all(uids.map(u=>db.collection('devices').doc(u).update({tokens:admin.firestore.FieldValue.arrayRemove(...bad)}).catch(()=>{})));
  return r.successCount;
}
