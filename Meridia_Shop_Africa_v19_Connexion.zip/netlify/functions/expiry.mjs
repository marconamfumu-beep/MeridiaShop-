import{db,adminUids,once,send}from'./_lib.mjs';
/* Chaque jour à 07h00 UTC (08h00 à Kinshasa) : rappel aux vendeurs dont l'abonnement expire sous 3 jours. */
export default async()=>{
  const n=Date.now(),day=new Date().toISOString().slice(0,10);let c=0;
  for(const s of(await db.collection('vendors').get()).docs){const v=s.data();if(v.suspended)continue;const d=Math.ceil((Math.max(v.trialEnd||0,v.paidUntil||0)-n)/864e5);
    if(d>=0&&d<=3&&await once('ex_'+s.id+'_'+day)){await send([s.id],'Abonnement bientôt expiré',d?'Il reste '+d+' jour(s). Renouvelez pour rester en ligne.':'Expire aujourd’hui. Renouvelez maintenant.','index.html');c++}}
  if(c&&await once('exa_'+day))await send(await adminUids(),'Abonnements à relancer',c+' vendeur(s) expirent sous 3 jours','admin.html');
};
export const config={schedule:'0 7 * * *'};
