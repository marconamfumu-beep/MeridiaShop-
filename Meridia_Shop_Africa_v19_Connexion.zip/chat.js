/* Meridia Shop : messagerie intégrée client ↔ vendeur (style Messenger). Données : Firestore (voir firebase.js › ZF.chat). */
(function(){
const $=s=>document.querySelector(s),toast=t=>{const e=$('#t');if(!e)return;e.textContent=t;e.className='on';clearTimeout(toast.h);toast.h=setTimeout(()=>e.className='',3500)};
let chats=[],unWatch=null,unMsgs=null,cur=null,curMsgs=[],mode='',panel=null,fab=null,wantHash='',uidSeen='';
const hm=t=>new Date(t).toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'}),
 day=t=>{const d=new Date(t),n=new Date();return d.toDateString()===n.toDateString()?hm(t):d.toLocaleDateString('fr-FR',{day:'2-digit',month:'short'})},
 dsep=t=>{const d=new Date(t),n=new Date(),y=new Date(Date.now()-864e5);return d.toDateString()===n.toDateString()?'Aujourd’hui':d.toDateString()===y.toDateString()?'Hier':d.toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long'})};
const ok=()=>!!(window.ZF&&window.ZF.chat&&window.ZF.uid);
const mine=c=>window.ZF.uid===c.vid?'v':'c';
const other=c=>{if(mine(c)==='v')return c.name||'Client';const v=((typeof ZM!=='undefined'&&ZM.load().vendors)||[]).find(x=>x.id===c.vid);return v?(v.shop||v.name):'Vendeur'};
const unread=c=>(mine(c)==='v'?c.unreadV:c.unreadC)||0;
const el=(t,c,x)=>{const e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e};
function total(){return chats.reduce((a,c)=>a+unread(c),0)}
function badge(){if(!fab)return;const n=total(),b=fab.querySelector('i');b.textContent=n>99?'99+':n;b.style.display=n?'flex':'none'}
function ensureFab(){/* bouton flottant supprimé : la messagerie s'ouvre depuis la barre basse */}
function ensurePanel(){if(panel)return;panel=el('div','zc');panel.addEventListener('click',e=>{if(e.target===panel)close()});document.body.appendChild(panel)}
function close(){if(unMsgs){unMsgs();unMsgs=null}cur=null;mode='';if(panel){panel.className='zc';panel.textContent=''}if(location.hash.indexOf('#chat-')===0)history.replaceState({},'',location.pathname+location.search)}
function notifBar(){if(!('Notification' in window)||Notification.permission==='granted'||Notification.permission==='denied')return null;const b=el('button','zc-alert','🔔 Être prévenu quand on vous répond');b.type='button';b.onclick=()=>window.ZF.notif().then(o=>{toast(o?'Alertes activées ✔':'Autorisation refusée');if(o)b.remove()}).catch(x=>toast(x.message||'Alertes indisponibles ici (sur iPhone : installez d’abord l’app sur l’écran d’accueil)'));return b}
function openList(){if(!ok())return toast('Messagerie indisponible : '+(window.ZF&&ZF.authHelp?ZF.authHelp():'réessayez dans un instant'));ensurePanel();mode='list';if(unMsgs){unMsgs();unMsgs=null}cur=null;drawList();panel.className='zc on'}
function drawList(){if(mode!=='list')return;const box=el('div','zc-box');const h=el('div','zc-head');const t=el('b',null,'Messages');const x=el('button','zc-x','✕');x.type='button';x.onclick=close;h.append(t,x);box.appendChild(h);const nb=notifBar();if(nb)box.appendChild(nb);
 const L=el('div','zc-list');if(!chats.length){L.appendChild(el('p','zc-empty','Aucune conversation pour l’instant. Touchez « Acheter » sur un produit pour écrire au vendeur.'))}
 chats.forEach(c=>{const r=el('button','zc-item');r.type='button';const av=el('span','zc-av',(other(c)||'?').trim().charAt(0).toUpperCase());const mid=el('span','zc-mid');mid.append(el('b',null,other(c)),el('small',null,(c.lastBy===mine(c)?'Vous : ':'')+(c.last||(c.productTitles||[]).join(', '))));const rt=el('span','zc-right');rt.appendChild(el('small',null,day(c.lastAt||c.date)));const u=unread(c);if(u)rt.appendChild(el('em',null,u>99?'99+':u));r.append(av,mid,rt);r.onclick=()=>openChat(c.id);L.appendChild(r)});
 box.appendChild(L);panel.textContent='';panel.appendChild(box)}
function openChat(id){if(!ok())return;ensurePanel();mode='chat';cur=id;curMsgs=[];panel.className='zc on';drawChat();if(unMsgs)unMsgs();unMsgs=window.ZF.chat.watchMsgs(id,m=>{curMsgs=m;drawMsgs();const c=chats.find(x=>x.id===id);if(c&&unread(c))window.ZF.chat.read(id,mine(c))})}
function drawChat(){const c=chats.find(x=>x.id===cur);const box=el('div','zc-box');const h=el('div','zc-head');const bk=el('button','zc-x','←');bk.type='button';bk.onclick=openList;const who=el('div','zc-who');who.append(el('b',null,c?other(c):'Conversation'),el('small',null,c&&c.productTitles&&c.productTitles.length?'À propos : '+c.productTitles.join(', '):''));const x=el('button','zc-x','✕');x.type='button';x.onclick=close;h.append(bk,who,x);box.appendChild(h);
 const nb=notifBar();if(nb)box.appendChild(nb);
 const M=el('div','zc-msgs');M.id='zcMsgs';box.appendChild(M);
 const f=el('div','zc-send');const i=el('textarea');i.rows=1;i.maxLength=1000;i.placeholder='Écrivez votre message…';i.id='zcIn';const b=el('button',null,'Envoyer');b.type='button';
 const go=async()=>{const v=i.value.trim();if(!v||b.disabled)return;b.disabled=true;try{await window.ZF.chat.send(cur,v);i.value='';i.style.height=''}catch(e){console.warn(e);toast('Message non envoyé : vérifiez votre connexion')}b.disabled=false;i.focus()};
 b.onclick=go;i.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!/Mobi|Android|iPhone/i.test(navigator.userAgent)){e.preventDefault();go()}});i.addEventListener('input',()=>{i.style.height='auto';i.style.height=Math.min(i.scrollHeight,110)+'px'});
 f.append(i,b);box.appendChild(f);panel.textContent='';panel.appendChild(box);drawMsgs()}
function drawMsgs(){const M=$('#zcMsgs');if(!M)return;const c=chats.find(x=>x.id===cur),me=c?mine(c):'c',near=M.scrollHeight-M.scrollTop-M.clientHeight<120||!M.children.length;M.textContent='';let last='';
 if(!curMsgs.length)M.appendChild(el('p','zc-empty','Aucun message. Dites bonjour 👋'));
 curMsgs.forEach(m=>{const ds=dsep(m.date);if(ds!==last){M.appendChild(el('div','zc-day',ds));last=ds}const b=el('div','zc-b '+(m.from===me?'me':'ot'));b.appendChild(el('span',null,m.text));b.appendChild(el('small',null,hm(m.date)));M.appendChild(b)});
 if(near)M.scrollTop=M.scrollHeight}
function startWatch(){if(unWatch){unWatch();unWatch=null}chats=[];badge();if(!ok())return;unWatch=window.ZF.chat.watchChats(l=>{chats=l;badge();if(mode==='list')drawList();else if(mode==='chat'){const c=chats.find(x=>x.id===cur);const s=$('.zc-who small');if(c&&s)s.textContent=c.productTitles&&c.productTitles.length?'À propos : '+c.productTitles.join(', '):'';}tryHash()})}
function tryHash(){if(!wantHash||!chats.some(c=>c.id===wantHash))return;const id=wantHash;wantHash='';openChat(id)}
function readHash(){if(location.hash.indexOf('#chat-')===0){wantHash=decodeURIComponent(location.hash.slice(6));tryHash()}}
window.addEventListener('hashchange',readHash);
window.ZCHAT={
 onAuth(u){ensureFab();if(!u)return;const k=u.uid;if(k===uidSeen&&unWatch)return;uidSeen=k;close();startWatch();readHash()},
 /* Appelé par « Acheter » : ouvre (ou crée) la conversation avec le vendeur et y envoie le message de commande. */
 async start(vid,items,intro,pid){
  let n='';try{n=localStorage.getItem('zs_name')||''}catch(e){}
  if(!n){n=(window.prompt('Votre prénom (le vendeur le verra) :','')||'').trim().slice(0,30)||'Client';try{localStorage.setItem('zs_name',n)}catch(e){}}
  ensurePanel();panel.className='zc on';panel.textContent='';const bx=el('div','zc-box');bx.appendChild(el('p','zc-empty','Ouverture de la discussion…'));panel.appendChild(bx);
  try{if(!(await window.ZF.ensure(10000)))throw new Error('auth');const id=await window.ZF.chat.ensure(vid,items,n);if(!chats.some(c=>c.id===id)){const c=await window.ZF.chat.get(id);if(c)chats=[c].concat(chats)}openChat(id);await window.ZF.chat.send(id,intro,pid,true)}
  catch(e){console.warn('chat',e);close();toast('Messagerie indisponible pour le moment : réessayez dans un instant')}
 },
 open:openChat,list:openList
};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ensureFab);else ensureFab();
})();
