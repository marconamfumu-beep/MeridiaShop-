/* Meridia Shop : Firebase Auth + Firestore. Actif seulement si firebase-config.js est rempli. */
import{initializeApp}from'https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js';
import{getAuth,onAuthStateChanged,signInAnonymously,signInWithEmailAndPassword,createUserWithEmailAndPassword,signOut,setPersistence,browserLocalPersistence}from'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import{getFirestore,initializeFirestore,persistentLocalCache,persistentMultipleTabManager,doc,getDoc,setDoc,deleteDoc,collection,query,where,onSnapshot,increment,updateDoc,orderBy,limit}from'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';
const C=window.ZCFG;
if(C&&!/^COLLEZ/.test(C.apiKey||'')){
const app=initializeApp(C),au=getAuth(app),authReady=setPersistence(au,browserLocalPersistence),fs=(()=>{const o={experimentalAutoDetectLongPolling:true};try{return initializeFirestore(app,{...o,localCache:persistentLocalCache({tabManager:persistentMultipleTabManager()})})}catch(e){try{return initializeFirestore(app,o)}catch(e2){return getFirestore(app)}}})(),DER={vendors:['s','pin'],products:['v','c']},
db={vendors:[],products:[],payments:[],requests:[],ledger:[],vpay:[],stats:[],set:{price:3,cur:'USD',early:3,later:1,limit:30,payTo:'Numéro Mobile Money à définir par l’administrateur'}},
snap={},tx=t=>{const e=document.getElementById('t');if(e){e.textContent=t;e.className='on';setTimeout(()=>e.className='',3500)}},
cl=(c,o)=>{const x={...o};(DER[c]||[]).forEach(k=>delete x[k]);return JSON.stringify(x)},
typing=()=>{const a=document.activeElement;return!!a&&/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)&&!/^(q|headerSearch)$/.test(a.id)},
doRender=f=>{if(!f&&typing()){late=true;return}late=false;const a=document.activeElement,id=a&&a.id,p=a&&a.selectionStart,e=a&&a.selectionEnd;if(window.render)window.render();if(id==='q'){const n=document.getElementById('q');if(n){n.focus();try{n.setSelectionRange(p,e)}catch(x){}}}},
refresh=f=>{if(f){clearTimeout(rt);rt=0;doRender(1);return}if(rt)return;rt=setTimeout(()=>{rt=0;doRender()},50)},
derive=()=>{db.products.forEach(p=>{p.v=0;p.c=0});db.vendors.forEach(v=>{v.s={}});db.stats.forEach(x=>{const p=db.products.find(y=>y.id===x.pid),v=db.vendors.find(y=>y.id===x.vid);if(p){p.v+=x.v||0;p.c+=x.c||0}if(v){const a=v.s[x.day]=v.s[x.day]||[0,0];a[0]+=x.v||0;a[1]+=x.c||0}})};
let subs=[],pubs=[],late=false,rt=0,noSet=false;const got=new Set();
addEventListener('focusout',()=>{if(late)setTimeout(()=>{if(late)doRender()},200)});
const listen=(c,q,arr)=>(arr||subs).push(onSnapshot(q||collection(fs,c),s=>{
 const old=new Map((db[c]||[]).map(o=>[o.id,o])),chg=new Set(s.docChanges().map(x=>x.doc.id)),ps=snap[c]||{},ns={};
 db[c]=s.docs.map(x=>(chg.has(x.id)||!old.has(x.id))?{...x.data(),id:x.id}:old.get(x.id));
 if(c==='products')db[c].sort((a,b)=>(b.date||0)-(a.date||0));if(c==='vendors')db[c].sort((a,b)=>(a.rank||0)-(b.rank||0));
 db[c].forEach(o=>{ns[o.id]=(!chg.has(o.id)&&ps[o.id]!==undefined)?ps[o.id]:cl(c,o)});snap[c]=ns;
 if((c==='vendors'||c==='products')&&(!s.metadata.fromCache||s.size)){got.add(c);if(got.has('vendors')&&got.has('products'))ZF.loaded=true}
 derive();if(c==='vendors'||c==='products')savePub();refresh()},e=>console.warn(c,e.code)));
const push=d=>{for(const c of['vendors','products','payments','requests','ledger','vpay']){const cur=d[c]||[],s=snap[c]=snap[c]||{},ids=new Set();cur.forEach(o=>{ids.add(o.id);const j=cl(c,o);if(s[o.id]!==j){const old=s[o.id],x=JSON.parse(j);s[o.id]=j;setDoc(doc(fs,c,o.id),x).then(()=>{if(c==='requests'&&!old)ZF.ping({type:'request',id:o.id});if(c==='payments'){if(!old)ZF.ping({type:'payment',id:o.id});else if(JSON.parse(old).status!==x.status)ZF.ping({type:'decision',id:o.id})}}).catch(e=>{tx('Action refusée par la sécurité Firebase');console.warn(c,e.code)})}});Object.keys(s).forEach(i=>{if(!ids.has(i)){delete s[i];deleteDoc(doc(fs,c,i)).catch(()=>tx('Suppression refusée'))}})}
const j=JSON.stringify(d.set);if(ZF.admin&&snap.set!==j){snap.set=j;setDoc(doc(fs,'config','settings'),d.set).catch(()=>tx('Réglages refusés'))}};
/* Messagerie client ↔ vendeur : chats/{vendeur_client} et chats/{…}/messages. Le client est identifié par son uid anonyme. */
const CH={
 async ensure(vid,items,name){const id=vid+'_'+ZF.uid,r=doc(fs,'chats',id),sn=await getDoc(r),ti=items.map(p=>String(p.title||'').slice(0,80)).slice(0,10),pi=items.map(p=>String(p.id)).slice(0,10);
  if(!sn.exists())await setDoc(r,{id,vid,cid:ZF.uid,productIds:pi,productTitles:ti,last:'',lastAt:Date.now(),lastBy:'c',unreadV:0,unreadC:0,date:Date.now(),name:String(name||'Client').slice(0,40)});
  else if(ti.length)await updateDoc(r,{productIds:pi,productTitles:ti});
  return id},
 async send(id,text,pid,quiet){text=String(text||'').trim().slice(0,1000);if(!text)return null;const r=doc(fs,'chats',id),c=(await getDoc(r)).data();if(!c)throw new Error('chat');
  const me=ZF.uid===c.vid?'v':'c',m=doc(collection(fs,'chats',id,'messages'));
  await setDoc(m,Object.assign({from:me,uid:ZF.uid,text,date:Date.now()},pid?{pid:String(pid).slice(0,60)}:{}));
  await updateDoc(r,{last:text.replace(/\s+/g,' ').slice(0,120),lastAt:Date.now(),lastBy:me,[me==='c'?'unreadV':'unreadC']:increment(1)});
  if(!quiet)ZF.ping({type:'message',chat:id,id:m.id});return m.id},
 async read(id,me){try{await updateDoc(doc(fs,'chats',id),{[me==='c'?'unreadC':'unreadV']:0})}catch(e){}},
 watchChats(cb){const L={a:[],b:[]},out=()=>{const m={};L.a.concat(L.b).forEach(c=>m[c.id]=c);cb(Object.values(m).sort((x,y)=>(y.lastAt||0)-(x.lastAt||0)))},
  e=err=>console.warn('chats',err.code),u1=onSnapshot(query(collection(fs,'chats'),where('cid','==',ZF.uid)),q=>{L.a=q.docs.map(d=>d.data());out()},e),
  u2=ZF.anon?null:onSnapshot(query(collection(fs,'chats'),where('vid','==',ZF.uid)),q=>{L.b=q.docs.map(d=>d.data());out()},e);
  return()=>{u1();u2&&u2()}},
 watchMsgs(id,cb){return onSnapshot(query(collection(fs,'chats',id,'messages'),orderBy('date'),limit(300)),q=>cb(q.docs.map(d=>Object.assign({id:d.id},d.data()))),e=>console.warn('msgs',e.code))},
 async get(id){const s=await getDoc(doc(fs,'chats',id));return s.exists()?s.data():null}
};
const ZF=window.ZF={on:true,db,uid:'',anon:true,admin:false,adminState:'no',loaded:false,push,chat:CH,
 async signUp(phone,pin,prof){
   await authReady;
   const email=phone+'@vendeur.meridiashop.africa';let user;
   try{user=(await createUserWithEmailAndPassword(au,email,pin)).user}
   catch(err){
     if(err.code!=='auth/email-already-in-use')throw err;
     user=(await signInWithEmailAndPassword(au,email,pin)).user;
     const existing=await getDoc(doc(fs,'vendors',user.uid));
     if(existing.exists())throw Object.assign(new Error('Ce numéro est déjà inscrit.'),{code:'auth/email-already-in-use'});
   }
   await setDoc(doc(fs,'vendors',user.uid),prof);
   const saved=await getDoc(doc(fs,'vendors',user.uid));
   if(!saved.exists())throw Object.assign(new Error('Le compte Firebase existe mais le profil vendeur n’a pas été confirmé.'),{code:'firestore/profile-not-saved'});
   ZF.ping({type:'vendor'});return user.uid;
 },
 authHelp(){const c=ZF.authErr||'';
   if(/operation-not-allowed|admin-restricted-operation/.test(c))return 'La connexion anonyme n’est pas activée dans Firebase : Authentication > Méthode de connexion > Anonyme.';
   if(/unauthorized-domain/.test(c))return 'Domaine non autorisé : ajoutez meridiashop.netlify.app dans Authentication > Paramètres > Domaines autorisés.';
   if(/invalid-api-key|api-key-not-valid|requests-from-referrer|referer/.test(c))return 'Clé API refusée : autorisez meridiashop.netlify.app dans les restrictions de la clé (Google Cloud).';
   if(/network|timeout/.test(c))return 'Réseau instable : réessayez dans un instant.';
   return c?('Erreur Firebase : '+c):'Délai dépassé : réessayez dans un instant.';
 },
 async ensure(ms){await authReady;if(ZF.uid)return true;const t0=Date.now();let bad=false;if(!au.currentUser){try{await signInAnonymously(au)}catch(e){console.warn('anon',e.code);ZF.authErr=e.code||'erreur';bad=/operation-not-allowed|admin-restricted|invalid-api-key|unauthorized-domain/.test(e.code||'')}}while(!bad&&!ZF.uid&&Date.now()-t0<(ms||10000))await new Promise(r=>setTimeout(r,250));return !!ZF.uid},
 async ping(b){try{const t=await au.currentUser.getIdToken();fetch('/.netlify/functions/notify',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+t},body:JSON.stringify(b)}).catch(()=>{})}catch(e){}},
 async notif(){
   if(!('Notification' in window)||!ZF.uid)return false;
   if(await Notification.requestPermission()!=='granted')return false;
   const{getMessaging,getToken}=await import('https://www.gstatic.com/firebasejs/10.14.1/firebase-messaging.js');
   const reg=await Promise.race([navigator.serviceWorker.ready,new Promise((_,j)=>setTimeout(()=>j(new Error('Service de notifications non prêt : rechargez la page')),8000))]);
   let tok;try{tok=await getToken(getMessaging(app),{vapidKey:C.vapidKey,serviceWorkerRegistration:reg})}catch(e){throw new Error('Jeton de notification refusé ('+(e.code||e.message)+')')}
   if(!tok)throw new Error('Aucun jeton de notification obtenu');
   const r=doc(fs,'devices',ZF.uid),cur=(await getDoc(r)).data();
   await setDoc(r,{tokens:[...new Set([tok,...((cur&&cur.tokens)||[])])].slice(0,5),date:Date.now()});
   const t=await ZF.testPush();if(!t.ok)throw new Error(t.msg);
   return true
 },
 async testPush(){
   try{const t=await au.currentUser.getIdToken();const r=await fetch('/.netlify/functions/notify',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+t},body:JSON.stringify({type:'test'})});const j=await r.json().catch(()=>({}));
     if(r.ok&&j.ok)return{ok:1};
     if(r.status===500||r.status===502)return{ok:0,msg:'Serveur de notification mal configuré : ajoutez FIREBASE_SERVICE_ACCOUNT dans Netlify'};
     if(j.reason==='no-device')return{ok:0,msg:'Aucun appareil enregistré'};
     if(r.ok)return{ok:0,msg:'Notification non délivrée : essayez de réactiver les alertes'};
     return{ok:0,msg:'Envoi impossible (code '+r.status+')'}}
   catch(e){return{ok:0,msg:'Serveur de notification injoignable'}}
 },
 async createPayment(payment){
   if(!au.currentUser||au.currentUser.isAnonymous)throw Object.assign(new Error('Connectez-vous avec votre compte vendeur.'),{code:'auth/unauthenticated'});
   if(payment.vid!==au.currentUser.uid)throw Object.assign(new Error('Compte vendeur invalide.'),{code:'payment/owner'});
   const ref=doc(fs,'payments',payment.id);
   await setDoc(ref,{
     id:payment.id,vid:payment.vid,amount:Number(payment.amount),cur:payment.cur,
     method:payment.method,ref:payment.ref,date:Number(payment.date),status:'en attente'
   });
   ZF.ping({type:'payment',id:payment.id});
   return true;
 },
 async putPhoto(id,vid,pid,d){await setDoc(doc(fs,'photos',id),{pid,vid,d,date:Date.now()})},
 async getPhoto(id){const s=await getDoc(doc(fs,'photos',id));return s.exists()?s.data().d:''},
 delPhotos(ids){(ids||[]).filter(Boolean).forEach(i=>deleteDoc(doc(fs,'photos',i)).catch(()=>{}))},
 signIn:async(e,p)=>{await authReady;return signInWithEmailAndPassword(au,e,p)},out:()=>signOut(au),
 hit:(pid,vid,t)=>{if(!au.currentUser)return;const k=ZM.dk();setDoc(doc(fs,'stats',pid+'_'+k),{pid,vid,day:k,[t]:increment(1)},{merge:true}).catch(()=>{})}};
/* Cache local boutiques et produits : affiché dès l'ouverture, puis mis à jour par Firestore (sans PIN ni données privées). */
const PC='ms_pub',savePub=()=>{try{const s=JSON.stringify({v:db.vendors.map(x=>{const y={...x};delete y.pin;delete y.s;return y}),p:db.products});if(s.length<4e6)localStorage.setItem(PC,s)}catch(e){}};
try{const c=JSON.parse(localStorage.getItem(PC)||'null');if(c&&Array.isArray(c.v)&&Array.isArray(c.p)){db.vendors=c.v;db.products=c.p;derive();refresh(1)}}catch(e){}
/* Lecture publique (règles : read: if true) : on démarre sans attendre la connexion anonyme. */
listen('vendors',null,pubs);listen('products',null,pubs);
pubs.push(onSnapshot(doc(fs,'config','settings'),s=>{if(s.exists()){noSet=false;db.set={...db.set,...s.data()};snap.set=JSON.stringify(db.set);refresh()}else{noSet=true;if(ZF.admin){noSet=false;setDoc(doc(fs,'config','settings'),db.set).catch(()=>{})}}},e=>console.warn('settings',e.code)));
setTimeout(()=>{if(!ZF.loaded){ZF.loaded=true;refresh()}},8000);
/* Session : restaurée sans attendre le réseau. Un « indice » local (uid + rôle admin) permet d'ouvrir l'interface tout de suite ;
   les droits réels restent décidés par Firebase et firestore.rules, et sont revérifiés en arrière-plan. */
const HK='ms_hint',hint=()=>{try{return JSON.parse(localStorage.getItem(HK))}catch(e){return null}},
saveHint=(id,a)=>{try{if(id)localStorage.setItem(HK,JSON.stringify({uid:id,admin:a?1:0}));else localStorage.removeItem(HK)}catch(e){}},
wait=ms=>new Promise(r=>setTimeout(r,ms)),
chkAdmin=async u=>{for(let i=0;i<4;i++){try{return(await getDoc(doc(fs,'admins',u.uid))).exists()}catch(e){if(e.code==='permission-denied')return false;await wait(1500*(i+1))}}return undefined},
PRIV=['payments','requests','ledger','stats','vpay'],
resetPriv=()=>{subs.forEach(f=>f());subs=[];PRIV.forEach(c=>{db[c]=[];snap[c]={}})},
setup=u=>{resetPriv();if(ZF.admin&&noSet){noSet=false;setDoc(doc(fs,'config','settings'),db.set).catch(()=>{})}PRIV.forEach(c=>{if(ZF.admin)listen(c);else if(!u.isAnonymous)listen(c,query(collection(fs,c),where('vid','==',u.uid)))});if(window.ZHOOK)window.ZHOOK();else refresh(1)};
let gen=0;
let anonTry=0;const anonLogin=()=>signInAnonymously(au).catch(e=>{console.warn('anon',e.code);ZF.authErr=e.code||'erreur';if(++anonTry<6&&!/operation-not-allowed|admin-restricted|invalid-api-key|unauthorized-domain/.test(e.code||''))setTimeout(()=>{if(!au.currentUser)anonLogin()},2000*anonTry)});
authReady.then(()=>onAuthStateChanged(au,u=>{setTimeout(()=>{if(window.ZCHAT)try{window.ZCHAT.onAuth(u)}catch(e){console.warn('chat',e)}},0)}));
authReady.then(()=>onAuthStateChanged(au,u=>{const my=++gen;
if(!u){resetPriv();ZF.admin=false;ZF.adminState='no';ZF.uid='';ZF.anon=true;saveHint(null);anonLogin();return}
ZF.uid=u.uid;ZF.anon=u.isAnonymous;
if(u.isAnonymous){ZF.admin=false;ZF.adminState='no';setup(u);return}
const h=hint(),same=!!h&&h.uid===u.uid;ZF.admin=same&&!!h.admin;ZF.adminState=same?(h.admin?'yes':'no'):'unknown';
setup(u);
if('Notification' in window&&Notification.permission==='granted')ZF.notif().catch(()=>{});
/* vérification du rôle en arrière-plan : n'empêche plus l'ouverture de l'interface et ne déconnecte jamais sur une simple panne réseau */
chkAdmin(u).then(r=>{if(my!==gen)return;
 if(r===undefined){if(ZF.adminState==='unknown'){ZF.adminState='fail';if(window.ZHOOK)window.ZHOOK()}return}
 saveHint(u.uid,r);const was=ZF.admin,ws=ZF.adminState;ZF.admin=r;ZF.adminState=r?'yes':'no';
 if(r!==was)setup(u);else if(ws!==ZF.adminState&&window.ZHOOK)window.ZHOOK()})})).catch(e=>{console.error('Firebase Auth persistence:',e);tx('Impossible de restaurer la session. Vérifiez la connexion.')});
}
