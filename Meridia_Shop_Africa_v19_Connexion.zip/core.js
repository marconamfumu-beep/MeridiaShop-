/* Meridia Shop : données et règles de la marketplace. */
const ZM=(()=>{const K='zm_db_live_v1',DAY=864e5,FB=!!(window.ZCFG&&!/^COLLEZ/.test(window.ZCFG.apiKey||'')),D=()=>({vendors:[],products:[],payments:[],requests:[],ledger:[],set:{price:3,cur:'USD',early:3,later:1,limit:30,payTo:'Numéro Mobile Money à définir par l’administrateur',payMpesa:'',payOrange:'',payAirtel:'',payCard:'',payUBA:''}});
const load=()=>{if(FB)return window.ZF&&ZF.db?ZF.db:D();try{return Object.assign(D(),JSON.parse(localStorage.getItem(K))||{})}catch(e){return D()}},
save=d=>{if(FB){if(window.ZF&&ZF.push)ZF.push(d);return true}try{localStorage.setItem(K,JSON.stringify(d));return true}catch(e){return false}},
esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),
addM=(t,m)=>{const d=new Date(t);d.setMonth(d.getMonth()+m);return d.getTime()},
end=v=>Math.max(v.trialEnd||0,v.paidUntil||0),
state=v=>v.suspended?'suspendu':(v.paidUntil||0)>=Date.now()?'actif':(v.trialEnd||0)>=Date.now()?'essai':'expiré',
live=v=>{const s=state(v);return s==='actif'||s==='essai'},
left=v=>Math.max(0,Math.ceil((end(v)-Date.now())/DAY)),
fd=t=>new Date(t).toLocaleDateString('fr-FR'),
freeFor=d=>d.vendors.length<d.set.limit?d.set.early:d.set.later,   /* les 30 premiers : 3 mois, ensuite : 1 mois */
spots=d=>Math.max(0,d.set.limit-d.vendors.length),
id=p=>p+Date.now().toString(36)+Math.random().toString(36).slice(2,5),
hash=s=>{let h=5381;for(const c of String(s))h=(h*33^c.charCodeAt(0))>>>0;return h.toString(36)},
img=(f,cb)=>{if(!f||!/^image\//.test(f.type))return cb('');const out=(src,w,h)=>{const k=Math.min(1,(FB?560:720)/Math.max(w,h)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(w*k));c.height=Math.max(1,Math.round(h*k));c.getContext('2d').drawImage(src,0,0,c.width,c.height);return c.toDataURL('image/jpeg',FB?.6:.7)},
old=()=>{const r=new FileReader();r.onerror=()=>cb('');r.onload=()=>{const i=new Image();i.onerror=()=>cb('');i.onload=()=>{try{cb(out(i,i.width,i.height))}catch(e){cb('')}};i.src=r.result};r.readAsDataURL(f)};
if(window.createImageBitmap)createImageBitmap(f).then(b=>{let u='';try{u=out(b,b.width,b.height)}catch(e){}if(b.close)b.close();cb(u)},old);else old()};
/* Photos HD : une vignette légère (640 px) reste dans le produit, la version HD (jusqu'à 1920 px) est stockée à part. */
const cvs=(src,w,h,max)=>{const k=Math.min(1,max/Math.max(w,h)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(w*k));c.height=Math.max(1,Math.round(h*k));const x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.imageSmoothingQuality='high';x.drawImage(src,0,0,c.width,c.height);return c},
fit=(c,max)=>{let cur=c;for(let r=0;r<4;r++){for(const q of[.88,.8,.72,.64,.56]){const u=cur.toDataURL('image/jpeg',q);if(u.length<=max)return u}cur=cvs(cur,cur.width,cur.height,Math.round(Math.max(cur.width,cur.height)*.85))}return cur.toDataURL('image/jpeg',.5)},
imgHD=(f,cb)=>{if(!f||!/^image\//.test(f.type))return cb(null);
const done=(src,w,h)=>{if(!FB)return{t:cvs(src,w,h,720).toDataURL('image/jpeg',.7),h:''};const H=cvs(src,w,h,1920),T=cvs(H,H.width,H.height,640);return{t:T.toDataURL('image/jpeg',.68),h:fit(H,620000)}},
old=()=>{const r=new FileReader();r.onerror=()=>cb(null);r.onload=()=>{const i=new Image();i.onerror=()=>cb(null);i.onload=()=>{try{cb(done(i,i.width,i.height))}catch(e){cb(null)}};i.src=r.result};r.readAsDataURL(f)};
if(window.createImageBitmap)createImageBitmap(f).then(b=>{let o=null;try{o=done(b,b.width,b.height)}catch(e){}if(b.close)b.close();o?cb(o):old()},old);else old()},
dropHD=l=>{if(FB&&window.ZF&&ZF.delPhotos)ZF.delPhotos((l||[]).flatMap(p=>p.hd||[]))};
const dk=t=>{const d=new Date(t||Date.now());return d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate()},
trk=(d,pid,t)=>{if(FB){const p=d.products.find(x=>x.id===pid);if(p&&window.ZF&&ZF.hit)ZF.hit(pid,p.vid,t);return}const p=d.products.find(x=>x.id===pid);if(!p)return;p[t]=(p[t]||0)+1;const v=d.vendors.find(x=>x.id===p.vid);if(v){v.s=v.s||{};const a=v.s[dk()]=v.s[dk()]||[0,0];a[t==='v'?0:1]++}},
wk=v=>Array.from({length:7},(_,i)=>{const t=Date.now()-(6-i)*DAY,a=(v.s||{})[dk(t)]||[0,0];return{l:'DLMMJVS'[new Date(t).getDay()],v:a[0],c:a[1]}}),
wka=d=>wk({}).map((z,i)=>d.vendors.reduce((a,v)=>{const x=wk(v)[i];return{l:a.l,v:a.v+x.v,c:a.c+x.c}},{l:z.l,v:0,c:0})),
bars=(A,B,L)=>{const m=Math.max(1,...A,...(B||[]));return `<div class="bars">${A.map((a,i)=>`<div><span><i title="${a}" style="height:${a/m*100}%"></i>${B?`<i class="c" title="${B[i]}" style="height:${B[i]/m*100}%"></i>`:''}</span><small>${L[i]}</small></div>`).join('')}</div>${B?'<p class="lg"><i></i> Vues <i class="c"></i> Contacts</p>':''}`},
hb=(l,v,m)=>`<div class="hb"><span>${esc(l)}</span><u><i style="width:${m?v/m*100:0}%"></i></u><b>${v}</b></div>`;

const HAS=!!(window.crypto&&crypto.subtle),b64=u=>btoa(String.fromCharCode(...new Uint8Array(u))),ub=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0)),
pbk=async(secret,salt)=>{const k=await crypto.subtle.importKey('raw',new TextEncoder().encode(String(secret)),'PBKDF2',false,['deriveBits']);return b64(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:ub(salt),iterations:150000},k,256))},
mk=async secret=>{if(!HAS)return hash(secret);const s=b64(crypto.getRandomValues(new Uint8Array(16)));return 'pb1$'+s+'$'+await pbk(secret,s)},
legacy=h=>!String(h||'').startsWith('pb1$'),
chk=async(secret,stored)=>{if(!stored)return false;if(!legacy(stored)){if(!HAS)return false;const p=String(stored).split('$');return p.length===3&&await pbk(secret,p[1])===p[2]}return hash(secret)===stored},
LK='zm_lk_',lkGet=k=>{try{return JSON.parse(localStorage.getItem(LK+k))||{n:0,u:0}}catch(e){return{n:0,u:0}}},
lockLeft=k=>Math.max(0,lkGet(k).u-Date.now()),
lockFail=k=>{const a=lkGet(k);a.n++;if(a.n>=5)a.u=Date.now()+Math.min(9e5,3e4*2**(a.n-5));try{localStorage.setItem(LK+k,JSON.stringify(a))}catch(e){}},
lockClear=k=>{try{localStorage.removeItem(LK+k)}catch(e){}};
const sod=t=>{const x=new Date(t);x.setHours(0,0,0,0);return x.getTime()},
rng=()=>{const m=new Date();m.setDate(1);m.setHours(0,0,0,0);return{day:sod(Date.now()),week:sod(Date.now())-6*DAY,month:m.getTime()}},
mv=(d,vid)=>{const a=(d.ledger||[]).filter(x=>x.vid===vid).map(x=>({id:x.id,t:x.type,a:+x.amount,c:x.cur,d:x.date,n:x.note}));d.payments.filter(p=>p.status==='validé').forEach(p=>{if(vid==='admin')a.push({t:'in',a:+p.amount,c:p.cur,d:p.vd||p.date,n:'Abonnement : '+((d.vendors.find(v=>v.id===p.vid)||{}).shop||'vendeur'),auto:1});else if(p.vid===vid)a.push({t:'out',a:+p.amount,c:p.cur,d:p.vd||p.date,n:'Abonnement Meridia Shop',auto:1})});return a.sort((x,y)=>y.d-x.d)},
sum=(a,c,f)=>a.filter(x=>x.c===c&&x.d>=f).reduce((r,x)=>{r[x.t]+=x.a;return r},{in:0,out:0}),
nf=x=>(+x).toLocaleString('fr-FR'),PL={day:'jour',week:'semaine',month:'mois'},
card=o=>{const s=sum(o.mv,o.cur,rng()[o.per]),t=sum(o.mv,o.cur,0),n=String(parseInt(hash(o.id),36)%9000+1000).slice(-4),pc=s.in?Math.min(100,Math.round(s.out/s.in*100)):s.out?100:0;return `<div class="wc"><div class="wr"><span class="wp"><i></i>${o.top}</span><b>${esc(o.name)}</b></div><div class="chip"></div><div class="wb"><small>RESTE EN CAISSE</small><b>${nf(t.in-t.out)}</b><span>${o.cur}</span></div><div class="wk"><div><small>Gagné · ${PL[o.per]}</small><b>${nf(s.in)}</b></div><div><small>Dépensé · ${PL[o.per]}</small><b>${nf(s.out)}</b></div></div><div class="wg"><i style="width:${pc}%"></i></div><div class="wf"><div><small>${o.lab}</small><b>•••• ${n}</b></div><button class="wa" data-wadd="1">+ Ajouter</button></div><div class="wq">${[['day','Jour'],['week','Semaine'],['month','Mois']].map(x=>`<button data-wp="${x[0]}" class="${o.per===x[0]?'on':''}">${x[1]}</button>`).join('')}${['USD','CDF'].map(c=>`<button data-wc="${c}" class="${o.cur===c?'on':''}">${c}</button>`).join('')}</div></div>`},
fin=(a,cur)=>{const R=rng(),r=(k,l)=>{const s=sum(a,cur,R[k]);return `<tr><td>${l}</td><td>${nf(s.in)}</td><td>${nf(s.out)}</td><td><b>${nf(s.in-s.out)}</b></td></tr>`};return `<div class="box tw"><h3>Gains et dépenses (${cur})</h3><table><thead><tr><th></th><th>Gagné</th><th>Dépensé</th><th>Net</th></tr></thead><tbody>${r('day','Aujourd’hui')}${r('week','7 jours')}${r('month','Ce mois')}</tbody></table></div><div class="box"><h3>Ajouter un mouvement</h3><form id="fg2"><div class="two"><label>Type<select name="type"><option value="in">Gain (vente, encaissement)</option><option value="out">Dépense</option></select></label><label>Montant<input name="amount" type="number" min="0.01" step="any" required></label><label>Devise<select name="cur"><option${cur==='USD'?' selected':''}>USD</option><option${cur==='CDF'?' selected':''}>CDF</option></select></label><label>Note<input name="note" maxlength="80" placeholder="Vente robe, transport…"></label></div><button class="pri">Enregistrer</button></form></div><div class="box"><h3>Derniers mouvements</h3>${a.slice(0,40).map(x=>`<div class="dg"><b>${x.t==='in'?'＋':'−'}</b><div>${esc(x.n||'—')}<small>${fd(x.d)} · ${nf(x.a)} ${x.c}</small></div>${x.auto||!x.id?'':`<button class="sm bad" data-ld="${x.id}">×</button>`}</div>`).join('')||'<p class="mut">Aucun mouvement.</p>'}</div>`},
addLed=(d,vid,g)=>{const a=Number(g('amount'));if(!isFinite(a)||a<=0||a>1e9)return 0;d.ledger=d.ledger||[];d.ledger.push({id:id('L'),vid,type:g('type')==='out'?'out':'in',amount:a,cur:g('cur')==='CDF'?'CDF':'USD',note:g('note').slice(0,80),date:Date.now()});return 1},
sc=I=>({score:Math.round(100*I.reduce((a,i)=>a+(i.s==='ok'?1:i.s==='warn'?.5:0),0)/I.length),items:I}),
dgv=r=>`<div class="box"><h3>Score de santé : ${r.score}/100</h3><div class="pg w" style="background:var(--line)"><i style="width:${r.score}%"></i></div>${r.items.map(i=>`<div class="dg ${i.s}"><b>${{ok:'✔',warn:'⚠',bad:'✖'}[i.s]}</b><div>${esc(i.t)}${i.s==='ok'?'':`<small>${esc(i.h)}</small>`}</div></div>`).join('')}</div>`,
diag=(d,v)=>{const I=[],A=(s,t,h)=>I.push({s,t,h}),n=Date.now(),m=d.products.filter(p=>p.vid===v.id),on=m.filter(p=>!p.hidden),R=(d.requests||[]).filter(r=>r.vid===v.id),old=R.filter(r=>r.status!=='Traitée'&&n-r.date>DAY).length,vu=m.reduce((a,p)=>a+(p.v||0),0),ct=m.reduce((a,p)=>a+(p.c||0),0),ph=p=>(p.images||(p.img?[p.img]:[])).length,st=state(v),lf=left(v),np=m.filter(p=>ph(p)<3).length,nd=m.filter(p=>(p.desc||'').length<40).length,ns=m.filter(p=>p.stock===0).length,hd=m.length-on.length;
A(st==='actif'||st==='essai'?(lf<=7?'warn':'ok'):'bad','Abonnement : '+st+(lf?' ('+lf+' j)':''),st==='expiré'?'Produits masqués : payez pour revenir en ligne.':lf<=7?'Moins de 8 jours : renouvelez à temps.':'Compte suspendu : contactez l’administration.');
A(v.verified?'ok':'warn','Badge Vérifié','Demandez la vérification à l’administration.');
A(v.stall&&v.city?'ok':'warn','Ville et étal renseignés','Ajoutez votre adresse pour être retrouvé sur Meridia Shop.');
A(/^\d{9,15}$/.test(v.phone||'')?'ok':'bad','Numéro WhatsApp valide','Vérifiez l’indicatif (243…).');
A(on.length>=3?'ok':on.length?'warn':'bad',on.length+' produit(s) en ligne','Visez au moins 3 produits.');
A(np?'warn':'ok',np+' produit(s) avec moins de 3 photos','Plusieurs angles rassurent l’acheteur.');
A(nd?'warn':'ok',nd+' produit(s) à description courte','Écrivez au moins 40 caractères.');
A(ns?'warn':'ok',ns+' produit(s) en rupture','Mettez le stock à jour ou masquez-les.');
A(hd?'warn':'ok',hd+' produit(s) masqué(s)','Ils ne sont pas visibles des clients.');
A(vu>=20&&ct/vu<.05?'warn':'ok','Taux de contact : '+(vu?Math.round(ct/vu*100):0)+'%','Améliorez photos, prix et description.');
A(old?'bad':'ok',old+' demande(s) sans réponse depuis 24 h','Répondez vite aux clients.');
A(d.payments.some(p=>p.vid===v.id&&p.status==='en attente')?'warn':'ok','Paiement en attente de validation','L’administration le validera sous peu.');
A(FB?'ok':'warn',FB?'Données synchronisées (Firebase)':'Mode local : données sur cet appareil seulement','Les clients d’autres téléphones ne vous voient pas tant que Firebase n’est pas configuré.');
return sc(I)},
adiag=d=>{const I=[],A=(s,t,h)=>I.push({s,t,h}),n=Date.now(),ex=d.vendors.filter(v=>live(v)&&left(v)<=7).length,pp=d.payments.filter(p=>p.status==='en attente'&&n-p.date>2*DAY).length,np=d.products.filter(p=>!((p.images&&p.images.length)||p.img)).length,nv=d.vendors.filter(v=>!d.products.some(p=>p.vid===v.id)).length,rq=(d.requests||[]).filter(r=>r.status!=='Traitée'&&n-r.date>2*DAY).length,kb=FB?0:Math.round((localStorage.getItem(K)||'').length/1024);
A(FB?'ok':'bad',FB?'Firebase actif (Auth + Firestore + règles)':'Mode local : données non partagées','Renseignez firebase-config.js et publiez firestore.rules.');
A(location.protocol==='https:'||location.hostname==='localhost'?'ok':'bad','Connexion sécurisée (HTTPS)','Publiez le site en HTTPS.');
A(ex?'warn':'ok',ex+' vendeur(s) expirent sous 7 jours','Relancez-les.');
A(pp?'bad':'ok',pp+' paiement(s) en attente depuis plus de 48 h','Validez ou refusez-les.');
A(np?'warn':'ok',np+' produit(s) sans photo','Demandez des photos aux vendeurs.');
A(nv?'warn':'ok',nv+' vendeur(s) sans produit','Accompagnez ces boutiques vides.');
A(rq?'warn':'ok',rq+' demande(s) client sans suite depuis 48 h','Rappelez les vendeurs.');
A((d.set.payMpesa||d.set.payOrange||d.set.payAirtel||d.set.payCard||d.set.payUBA|| (d.set.payTo&&!/à définir/.test(d.set.payTo)))?'ok':'bad','Moyens de paiement configurés','À renseigner dans Réglages.');
if(!FB)A(kb>3500?'bad':kb>2000?'warn':'ok','Stockage local : '+kb+' Ko sur ~5 000 Ko','Les photos saturent vite : passez à Firebase.');
return sc(I)};

return{fb:FB,mv,card,fin,addLed,diag,adiag,dgv,mk,chk,legacy,lockLeft,lockFail,lockClear,dk,trk,wk,wka,bars,hb,load,save,esc,addM,end,state,live,left,fd,freeFor,spots,id,hash,img,imgHD,dropHD,CATS:['Vêtements','Chaussures','Sacs et accessoires','Électronique','Beauté','Maison','Alimentation','Autre']}})();
if('serviceWorker' in navigator)addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));
