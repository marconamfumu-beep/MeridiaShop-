/* Meridia Shop : moyens de paiement par pays.
   - Catalogue des pays africains (indicatif, devise, opérateurs Mobile Money, présence UBA).
   - Moyens de paiement de la plateforme gérés par l'administrateur : d.set.methods (document Firestore config/settings, lisible par les vendeurs).
   - Aucun numéro complet de carte ni CVV n'est jamais accepté : liens de paiement sécurisés, 4 derniers chiffres et instructions uniquement. */
(function(){
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
/* [indicatif, devise, présence UBA, opérateurs Mobile Money / portefeuilles] */
const C={
'Afrique du Sud':['27','ZAR',0,['MTN MoMo','VodaPay']],
'Algérie':['213','DZD',0,['Baridimob']],
'Angola':['244','AOA',0,['Multicaixa Express','Unitel Money']],
'Bénin':['229','XOF',1,['MTN Mobile Money','Moov Money','Celtiis Cash']],
'Botswana':['267','BWP',0,['Orange Money','MyZaka']],
'Burkina Faso':['226','XOF',1,['Orange Money','Moov Money','Coris Money']],
'Burundi':['257','BIF',0,['Lumicash','EcoCash']],
'Cameroun':['237','XAF',1,['MTN Mobile Money','Orange Money','Express Union Mobile']],
'Cap-Vert':['238','CVE',0,['Vinti4']],
'Comores':['269','KMF',0,['Huri Money']],
'Congo':['242','XAF',1,['MTN Mobile Money','Airtel Money']],
'Côte d’Ivoire':['225','XOF',1,['Orange Money','MTN Mobile Money','Moov Money','Wave']],
'Djibouti':['253','DJF',0,['D-Money','Waafi']],
'Égypte':['20','EGP',0,['Vodafone Cash','Orange Cash','Etisalat Cash','InstaPay']],
'Érythrée':['291','ERN',0,[]],
'Eswatini':['268','SZL',0,['MTN MoMo']],
'Éthiopie':['251','ETB',0,['Telebirr','CBE Birr','M-Birr']],
'Gabon':['241','XAF',1,['Airtel Money','Moov Money']],
'Gambie':['220','GMD',0,['Wave','QMoney','Afrimoney']],
'Ghana':['233','GHS',1,['MTN Mobile Money','Telecel Cash','AirtelTigo Money']],
'Guinée':['224','GNF',1,['Orange Money','MTN Mobile Money']],
'Guinée-Bissau':['245','XOF',0,['Orange Money','MTN Mobile Money']],
'Guinée équatoriale':['240','XAF',0,[]],
'Kenya':['254','KES',1,['M-Pesa','Airtel Money','T-Kash']],
'Lesotho':['266','LSL',0,['M-Pesa','EcoCash']],
'Libéria':['231','LRD',1,['Orange Money','MTN MoMo']],
'Libye':['218','LYD',0,['Sadad']],
'Madagascar':['261','MGA',0,['MVola','Orange Money','Airtel Money']],
'Malawi':['265','MWK',0,['Airtel Money','TNM Mpamba']],
'Mali':['223','XOF',1,['Orange Money','Moov Money']],
'Maroc':['212','MAD',0,['Orange Money','inwi money','M-Wallet']],
'Maurice':['230','MUR',0,['MyT Money','Juice']],
'Mauritanie':['222','MRU',0,['Bankily','Masrvi','Sedad']],
'Mozambique':['258','MZN',1,['M-Pesa','e-Mola','mKesh']],
'Namibie':['264','NAD',0,['PayToday','Blue Wallet']],
'Niger':['227','XOF',0,['Airtel Money','Orange Money','Moov Money','Mynita']],
'Nigeria':['234','NGN',1,['OPay','PalmPay','Moniepoint','Paga']],
'Ouganda':['256','UGX',1,['MTN Mobile Money','Airtel Money']],
'République centrafricaine':['236','XAF',0,['Orange Money','Moov Money']],
'République démocratique du Congo':['243','CDF',1,['Vodacom M-Pesa','Orange Money','Airtel Money','Africell Money']],
'Rwanda':['250','RWF',0,['MTN Mobile Money','Airtel Money']],
'Sao Tomé-et-Principe':['239','STN',0,[]],
'Sénégal':['221','XOF',1,['Wave','Orange Money','Free Money']],
'Seychelles':['248','SCR',0,[]],
'Sierra Leone':['232','SLE',1,['Orange Money','Afrimoney']],
'Somalie':['252','SOS',0,['EVC Plus','eDahab','Sahal']],
'Soudan':['249','SDG',0,['Bankak']],
'Soudan du Sud':['211','SSP',0,['MGurush']],
'Tanzanie':['255','TZS',1,['M-Pesa','Mixx by Yas','Airtel Money','HaloPesa']],
'Tchad':['235','XAF',1,['Airtel Money','Moov Money']],
'Togo':['228','XOF',0,['Moov Money','T-Money']],
'Tunisie':['216','TND',0,['D17','Flouci']],
'Zambie':['260','ZMW',1,['MTN Mobile Money','Airtel Money','Zamtel Kwacha']],
'Zimbabwe':['263','USD',0,['EcoCash','OneMoney','InnBucks']]
};
const COUNTRIES=Object.keys(C);
const TYPES=[
 ['mm','Mobile Money'],
 ['card','Carte bancaire (Visa / Mastercard)'],
 ['uba','Carte prépayée UBA'],
 ['prepaid','Autre carte prépayée'],
 ['bank','Virement / compte bancaire']
];
const TLAB=Object.fromEntries(TYPES);
const BANKS=['UBA (United Bank for Africa)','Ecobank','Afriland First Bank','Access Bank','Equity Bank','Standard Bank','Rawbank','Banque Atlantique','Société Générale','BOA (Bank of Africa)','Coris Bank'];
const ALL='*';
const MAX=120;

const info=c=>C[c]?{cc:C[c][0],cur:C[c][1],uba:!!C[c][2],mm:C[c][3]}:{cc:'',cur:'',uba:false,mm:[]};
function suggestions(country,type){
  if(type==='mm')return info(country).mm;
  if(type==='bank')return BANKS;
  if(type==='uba')return ['UBA Prepaid Card','UBA Leo Card'];
  if(type==='card')return ['Visa','Mastercard','Visa / Mastercard'];
  return [];
}
/* Détecte un numéro de carte complet (13 à 19 chiffres, contrôle de Luhn) dans un texte. */
function luhn(n){let s=0,alt=false;for(let i=n.length-1;i>=0;i--){let d=+n[i];if(alt){d*=2;if(d>9)d-=9}s+=d;alt=!alt}return s%10===0}
function hasCardNumber(t){
  const m=String(t||'').match(/\d(?:[ -]?\d){12,18}/g)||[];
  return m.some(x=>{const n=x.replace(/\D/g,'');return n.length>=13&&n.length<=19&&luhn(n)});
}
function cvvLike(t){return /\b(cvv|cvc|cryptogramme|code de s[ée]curit[ée])\b\s*[:=]?\s*\d{3,4}/i.test(String(t||''))}
const httpsOk=u=>{try{const x=new URL(u);return x.protocol==='https:'&&!!x.hostname&&x.hostname.includes('.')}catch(e){return false}};
const cleanNum=s=>String(s||'').replace(/[^\d+]/g,'').slice(0,20);

/* Valide et normalise un moyen de paiement saisi par l'administrateur. */
function validate(f){
  const country=f.country===ALL||C[f.country]?f.country:'';
  if(!country)return{error:'Choisissez un pays'};
  const type=TLAB[f.type]?f.type:'';
  if(!type)return{error:'Choisissez un type de moyen de paiement'};
  const provider=String(f.provider||'').trim().slice(0,60);
  if(!provider)return{error:type==='bank'?'Indiquez le nom de la banque':'Indiquez l’opérateur ou le nom du moyen de paiement'};
  const holder=String(f.holder||'').trim().slice(0,60);
  const number=String(f.number||'').trim().slice(0,40);
  const link=String(f.link||'').trim().slice(0,300);
  const note=String(f.note||'').trim().slice(0,400);
  const last4=String(f.last4||'').trim();
  const exp=String(f.exp||'').trim();
  if(type==='mm'){
    if(!/^\+?[\d ]{6,18}$/.test(number)||number.replace(/\D/g,'').length<6)return{error:'Numéro Mobile Money invalide'};
    if(!holder)return{error:'Indiquez le nom du titulaire du compte'};
  }else if(type==='bank'){
    if(number.replace(/\s/g,'').length<6||!/^[A-Za-z0-9 -]+$/.test(number))return{error:'Numéro de compte ou IBAN invalide'};
    if(!holder)return{error:'Indiquez le nom du titulaire du compte'};
  }else{
    if(!link&&!note&&!last4)return{error:'Ajoutez un lien de paiement sécurisé, des instructions ou les 4 derniers chiffres de la carte'};
    if(link&&!httpsOk(link))return{error:'Le lien de paiement doit commencer par https://'};
    if(last4&&!/^\d{4}$/.test(last4))return{error:'Entrez uniquement les 4 derniers chiffres de la carte'};
    if(exp&&!/^(0[1-9]|1[0-2])\/\d{2}$/.test(exp))return{error:'Expiration au format MM/AA'};
    if(number)return{error:'Ne saisissez pas de numéro de carte : utilisez un lien sécurisé ou les 4 derniers chiffres'};
  }
  if([holder,note,link,number,exp].some(x=>hasCardNumber(x)))return{error:'Numéro complet de carte détecté : il ne doit jamais être enregistré'};
  if([holder,note].some(cvvLike))return{error:'Ne saisissez jamais le code CVV'};
  return{ok:true,item:{country,type,provider,holder,number:type==='mm'?cleanNum(number):number,link,note,last4:last4||'',exp:exp||'',on:f.on===false||f.on===0?0:1}};
}
const uid=()=>'M'+Date.now().toString(36)+Math.random().toString(36).slice(2,6);
function add(set,f){
  const r=validate(f);if(r.error)return r;
  set.methods=set.methods||[];
  if(set.methods.length>=MAX)return{error:'Limite de moyens de paiement atteinte'};
  const k=x=>[x.country,x.type,x.provider.toLowerCase(),x.number].join('|');
  if(set.methods.some(x=>k(x)===k(r.item)&&x.id!==f.id))return{error:'Ce moyen de paiement existe déjà pour ce pays'};
  const item=Object.assign({id:uid(),date:Date.now()},r.item);
  set.methods.push(item);return{ok:true,item};
}
function update(set,id,f){
  const m=(set.methods||[]).find(x=>x.id===id);if(!m)return{error:'Moyen de paiement introuvable'};
  const r=validate(f);if(r.error)return r;
  Object.assign(m,r.item);return{ok:true,item:m};
}
function toggle(set,id){const m=(set.methods||[]).find(x=>x.id===id);if(!m)return false;m.on=m.on?0:1;return true}
function remove(set,id){const n=(set.methods||[]).length;set.methods=(set.methods||[]).filter(x=>x.id!==id);return set.methods.length<n}

/* Moyens actifs visibles par un vendeur d'un pays donné. */
function forCountry(set,country){
  const a=(set&&set.methods||[]).filter(m=>m.on);
  const mine=a.filter(m=>m.country===country||m.country===ALL);
  return{mine,others:a.filter(m=>!mine.includes(m))};
}
function label(m){return (m.type==='bank'?'Virement ':'')+m.provider+(m.country&&m.country!==ALL?' ('+m.country+')':'')}
function methodLabel(m){return label(m).slice(0,80)}
/* Libellés acceptés pour un paiement d'abonnement d'un vendeur. */
function vendorChoices(set,country){
  const f=forCountry(set,country);
  const list=f.mine.length?f.mine:f.mine.concat(f.others);
  return list.map(methodLabel);
}
const CASH='Espèces (agent Meridia Shop)';

function detail(m){
  const p=[];
  if(m.holder)p.push('Titulaire : '+esc(m.holder));
  if(m.number)p.push((m.type==='mm'?'Numéro : ':'Compte : ')+'<b>'+esc(m.type==='mm'&&info(m.country).cc&&!m.number.startsWith('+')?'+'+info(m.country).cc+' '+m.number.replace(/^0/,''):m.number)+'</b>');
  if(m.last4)p.push('Carte •••• '+esc(m.last4)+(m.exp?' · exp. '+esc(m.exp):''));
  if(m.link&&httpsOk(m.link))p.push('<a href="'+esc(m.link)+'" target="_blank" rel="noopener noreferrer">Ouvrir le lien de paiement sécurisé</a>');
  if(m.note)p.push(esc(m.note));
  return p.join('<br>');
}
/* Bloc affiché au vendeur dans « Payer mon abonnement ». */
function vendorBlock(set,country){
  const f=forCountry(set,country),it=m=>'<div class="pm-line"><b>'+esc(m.provider)+'</b> <span class="pm-tag">'+esc(TLAB[m.type])+(m.country===ALL?' · tous pays':'')+'</span><small>'+detail(m)+'</small></div>';
  let h='';
  if(f.mine.length)h+='<h4 class="pm-h">Payer depuis '+esc(country||'votre pays')+'</h4>'+f.mine.map(it).join('');
  if(f.others.length)h+='<details class="pm-more"><summary>'+(f.mine.length?'Moyens d’autres pays':'Moyens disponibles')+' ('+f.others.length+')</summary>'+f.others.map(m=>it(m).replace('</b> ','</b> <em>'+esc(m.country)+'</em> ')).join('')+'</details>';
  return h;
}

/* ---------- Page administrateur ---------- */
let editId='',fCountry='',fType='mm';
function typeOpts(sel){return TYPES.map(t=>'<option value="'+t[0]+'"'+(t[0]===sel?' selected':'')+'>'+esc(t[1])+'</option>').join('')}
function countryOpts(sel,all){return (all?'<option value="'+ALL+'"'+(sel===ALL?' selected':'')+'>Tous les pays</option>':'')+COUNTRIES.map(c=>'<option'+(c===sel?' selected':'')+'>'+esc(c)+'</option>').join('')}
function datalist(country,type){return suggestions(country,type).map(s=>'<option value="'+esc(s)+'">').join('')}
function adminPanel(d){
  const set=d.set||{},ms=set.methods||[],e=ms.find(x=>x.id===editId)||null;
  const cur=e||{country:fCountry||'République démocratique du Congo',type:fType,on:1};
  const rows=ms.slice().sort((a,b)=>(a.country===ALL?'':a.country).localeCompare(b.country===ALL?'':b.country,'fr')).map(m=>
    '<tr><td>'+(m.country===ALL?'Tous les pays':esc(m.country))+'</td><td>'+esc(TLAB[m.type]||m.type)+'</td><td>'+esc(m.provider)+'</td><td>'+detail(m)+'</td><td><span class="tag '+(m.on?'validé':'refusé')+'">'+(m.on?'Actif':'Masqué')+'</span></td><td class="pm-act"><button class="sm" data-pm-edit="'+esc(m.id)+'">Modifier</button><button class="sm" data-pm-tog="'+esc(m.id)+'">'+(m.on?'Masquer':'Activer')+'</button><button class="sm bad" data-pm-del="'+esc(m.id)+'">Supprimer</button></td></tr>').join('');
  const nUba=ms.filter(m=>m.type==='uba').length,nCard=ms.filter(m=>m.type==='card').length,nMm=ms.filter(m=>m.type==='mm').length;
  return '<div class="box"><h3>Moyens de paiement par pays</h3><p class="mut">Ajoutez, pays par pays, les moyens sur lesquels les vendeurs vous règlent leur abonnement : Mobile Money, carte bancaire, carte prépayée UBA ou virement. Chaque vendeur voit en priorité les moyens de son pays.</p>'+
  '<div class="kp"><div><b>'+ms.length+'</b><small>Moyens enregistrés</small></div><div><b>'+nMm+'</b><small>Mobile Money</small></div><div><b>'+nUba+'</b><small>Cartes UBA</small></div><div><b>'+nCard+'</b><small>Cartes bancaires</small></div></div></div>'+
  '<form id="pm-form" class="box vp-form" autocomplete="off"><h3>'+(e?'Modifier le moyen de paiement':'Ajouter un moyen de paiement')+'</h3>'+
  '<div class="vp-grid">'+
  '<label>Pays<select name="country" id="pm-country">'+countryOpts(cur.country,true)+'</select></label>'+
  '<label>Type<select name="type" id="pm-type">'+typeOpts(cur.type)+'</select></label>'+
  '<label><span id="pm-prov-l">Opérateur / banque</span><input name="provider" id="pm-prov" list="pm-sug" required maxlength="60" value="'+esc(cur.provider||'')+'" placeholder="Ex. Orange Money, UBA Prepaid Card"><datalist id="pm-sug">'+datalist(cur.country,cur.type)+'</datalist></label>'+
  '<label>Nom du titulaire<input name="holder" maxlength="60" value="'+esc(cur.holder||'')+'" placeholder="Nom du compte"></label>'+
  '<label id="pm-num-w"><span id="pm-num-l">Numéro / compte</span><input name="number" inputmode="tel" maxlength="40" value="'+esc(cur.number||'')+'" placeholder="+243…"></label>'+
  '<label class="pm-cardonly">4 derniers chiffres de la carte (facultatif)<input name="last4" inputmode="numeric" pattern="[0-9]{4}" maxlength="4" value="'+esc(cur.last4||'')+'" placeholder="4567"></label>'+
  '<label class="pm-cardonly">Expiration MM/AA (facultatif)<input name="exp" inputmode="numeric" maxlength="5" value="'+esc(cur.exp||'')+'" placeholder="12/27"></label>'+
  '<label class="pm-cardonly">Lien de paiement sécurisé (https)<input name="link" type="url" maxlength="300" value="'+esc(cur.link||'')+'" placeholder="https://…"></label>'+
  '</div><label>Instructions pour le vendeur (facultatif)<textarea name="note" rows="2" maxlength="400" placeholder="Ex. Indiquez votre numéro de boutique en référence.">'+esc(cur.note||'')+'</textarea></label>'+
  '<label class="pm-chk"><input type="checkbox" name="on"'+(cur.on?' checked':'')+'> Visible par les vendeurs</label>'+
  '<p class="mut">Ne saisissez jamais le numéro complet d’une carte ni le CVV : seuls un lien sécurisé UBA / prestataire agréé, les 4 derniers chiffres et des instructions sont acceptés.</p>'+
  '<button class="pri">'+(e?'Enregistrer les modifications':'Ajouter ce moyen de paiement')+'</button>'+(e?' <button type="button" class="sm" data-pm-cancel="1">Annuler</button>':'')+'</form>'+
  '<div class="box tw"><table><thead><tr><th>Pays</th><th>Type</th><th>Nom</th><th>Détails</th><th>État</th><th></th></tr></thead><tbody>'+(rows||'<tr><td colspan="6">Aucun moyen de paiement. Ajoutez-en un ci-dessus.</td></tr>')+'</tbody></table></div>';
}
function syncForm(){
  const t=document.getElementById('pm-type'),c=document.getElementById('pm-country');if(!t||!c)return;
  const ty=t.value,co=c.value;
  const dl=document.getElementById('pm-sug');if(dl)dl.innerHTML=datalist(co,ty);
  const card=ty==='card'||ty==='uba'||ty==='prepaid';
  document.querySelectorAll('.pm-cardonly').forEach(x=>x.style.display=card?'':'none');
  const nw=document.getElementById('pm-num-w');if(nw)nw.style.display=card?'none':'';
  const nl=document.getElementById('pm-num-l');if(nl)nl.textContent=ty==='bank'?'Numéro de compte / IBAN':'Numéro Mobile Money';
  const pl=document.getElementById('pm-prov-l');if(pl)pl.textContent=ty==='bank'?'Banque':ty==='mm'?'Opérateur Mobile Money':'Nom de la carte';
  const n=document.querySelector('#pm-form [name=number]');if(n&&ty==='mm'&&!n.value){const i=info(co);n.placeholder=i.cc?'+'+i.cc+'…':'+…'}
  const p=document.getElementById('pm-prov');if(p&&!p.value&&(ty==='uba'))p.placeholder='UBA Prepaid Card';
}
function wire(){
  const tok=(m)=>{const e=document.getElementById('t');if(!e)return;e.textContent=m;e.className='on';setTimeout(()=>e.className='',3000)};
  const save=fn=>{const d=ZM.load();d.set=d.set||{};if(ZM.fb&&!(window.ZF&&ZF.admin)){tok('Réservé à l’administrateur');return}const r=fn(d.set);if(r&&r.error){tok(r.error);return}ZM.save(d);if(window.render)window.render();return r};
  document.addEventListener('change',e=>{if(e.target&&(e.target.id==='pm-type'||e.target.id==='pm-country')){
    if(e.target.id==='pm-type'){const t=e.target.value,p=document.getElementById('pm-prov');if(p&&!editId){p.value=t==='uba'?'UBA Prepaid Card':''}}
    syncForm()}});
  document.addEventListener('submit',e=>{if(e.target.id!=='pm-form')return;e.preventDefault();e.stopImmediatePropagation();
    const f=new FormData(e.target),o={};['country','type','provider','holder','number','last4','exp','link','note'].forEach(k=>o[k]=String(f.get(k)||''));o.on=f.get('on')?1:0;
    const r=save(s=>editId?update(s,editId,o):add(s,o));
    if(r&&r.ok){fCountry=o.country;fType=o.type;const was=editId;editId='';tok(was?'Moyen de paiement modifié ✔':'Moyen de paiement ajouté ✔');if(window.render)window.render()}
  },true);
  document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;
    if(b.dataset.pmEdit){editId=b.dataset.pmEdit;if(window.render)window.render();scrollTo(0,0);return}
    if(b.dataset.pmCancel){editId='';if(window.render)window.render();return}
    if(b.dataset.pmTog){save(s=>toggle(s,b.dataset.pmTog)?{ok:1}:{error:'Introuvable'});return}
    if(b.dataset.pmDel){if(!confirm('Supprimer ce moyen de paiement ?'))return;if(editId===b.dataset.pmDel)editId='';save(s=>remove(s,b.dataset.pmDel)?{ok:1}:{error:'Introuvable'});tok('Moyen de paiement supprimé');return}
  });
  let last=null;new MutationObserver(()=>{const f=document.getElementById('pm-form');if(f&&f!==last){last=f;syncForm()}else if(!f)last=null}).observe(document.body,{childList:true,subtree:true});
}
const PAYM={C,COUNTRIES,TYPES,TLAB,ALL,CASH,info,suggestions,validate,add,update,toggle,remove,forCountry,vendorChoices,methodLabel,vendorBlock,adminPanel,hasCardNumber,cvvLike,luhn,esc};
if(typeof window!=="undefined")window.PAYM=PAYM;
if(typeof document!=='undefined'&&document.querySelector&&document.querySelector('.ad-shell'))wire();
if(typeof module!=='undefined')module.exports=PAYM;
})();
