/* Configuration du projet Firebase Meridia Shop (meridiashop1).
   Ces valeurs sont publiques par conception (identifiants de l'application Web).
   Ne mettez jamais ici de clé privée de compte de service. */
window.ZCFG={
  apiKey:'AIzaSyBspgB7PLvJAOb15NJpFnUBlr7DQwwOxYE',
  authDomain:'meridiashop1.firebaseapp.com',
  projectId:'meridiashop1',
  storageBucket:'meridiashop1.firebasestorage.app',
  messagingSenderId:'224739691731',
  appId:'1:224739691731:web:863ac117574730ee20d826',
  vapidKey:'BO3RGfMll5hBUZTQ79Z4SOJblHGN4_vVTxpPnRdIxxJMph5vxbi4EvDmMlgEN50E4cT-geYi7hAOBfR76WxDBKY'
};
